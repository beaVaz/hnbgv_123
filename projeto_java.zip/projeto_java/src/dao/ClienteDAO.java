/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import projeto_java.ConnectionFactory;
import projeto_java.modelo.CLiente;

/**
 *
 * @author Beatriz_24489
 */
public class ClienteDAO {
    private Connection con;
    public ClienteDAO(){
    this.con = new ConnectionFactory().getConnetion();
    }
    public void adiciona (Cliente c){
    String sql = "insert into cliente"
            +"(nome,idade,salario)"
            + "values(?,?,?)";
    try{
    PreparedStatment stmt = con.prepareStatement(sql);
    stmt.setString(1,c.getNome());
    stmt.setInt(2, c.getIdade());
    stmt.setDouble(3, c.getSalario());
    
    stmt.execute();
    stmt.close();
    }catch (SQLException e){
        throw new RuntimeException(e);
    }
    }
      public void altera(Cliente c){
      String sql = "update cliente set nome =?,"
              +"idade=?,"+"salario=?"
              +"wherre cod_cliente =?;";
      
      try {
      PreparedStatement stmt = con.prepareStatement(sql);
      stmt.setString(1,c.getNome());
      stmt.setInt(2, c.getIdade());
      stmt.setDouble(3,c.getSalario());
      stmt.execute();
      stmt.close();
      }catch (SQLException e){
      throw new RuntimeException (e);
      }
      }
      public void Remover(Cliente c){
      try{
      PreparedStatement stmt = con.prepareStatement("Delete from cliente where cod_cliente =?");
      stmt.setInt(1,c.getCod_cleinte());
      stmt.execute();
      stmt.close();
      }catch (SQLException e){
      throw new RuntimeException(e);
      }
      
      public void pesquisar(Cliente c){
      try{
      PreparedStatement stmt = this.con.prepareStatement("select * from where cod_cliente"+c.getCod_cliente());
      ResultSet rs = stmt.executeQuery();
      while (rs.next()){
      c.setCod_cliente(rs.getInt("cod_cliente"));
      c.setNome(rs.getString("nome"));
      c.setIdade(rs.getDouble("salario"));
      }
      rs.close();
      stmt.close();
      }catch(SQLException e){
      throw new RuntimeException(e);
      }
      }
      public List<Cliente>getLista(){
       try{
        List<Cliente>clientes = new ArrayList <Cliente>();
        PreparedStatement stmt = this.con.prepareStatement("Select * from cliente");
        ResultSet rs = stmt.executeQuery();
        while (rs.next()){
            Cliente c = new Cliente();
            c.setCod_cliente(rs.getInt("cod_cliente"));
            c.setNome(rs.getString("nome"));
            clientes.add(c);
            
        }rs.close();
        stmt.close();
        return clientes;
       }catch (SQLException e){
           throw new RuntimeException(e);
       }
       } 
      }
      



