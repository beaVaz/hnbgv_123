/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projeto_java;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



/**
 *
 * @author Beatriz_24489
 */
public class ConnectionFactory {
    public Connection getConnetion(){
System.out.println("Conectando ao Banco de Dados");
try{
return
        DriverManager.getConnection("doc:mysql://localhost/projeto_java", "root", "root");
}catch (SQLException e){
throw new RuntimeException(e);
}
}
    public static void main(String[] args){
    new ConnectionFactory().getConnetion();
    System.out.println("Conexão criada com sucesso");
    }
}
